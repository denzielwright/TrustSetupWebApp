import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages } = await req.json()

  const result = streamText({
    model: openai("gpt-4-turbo"),
    messages,
    system: `You are a helpful AI assistant specializing in trust and estate planning. 
    You provide guidance on living revocable trusts, asset protection, and estate planning matters. 
    Always remind users to consult with qualified legal professionals for specific legal advice.
    Keep responses clear, professional, and focused on trust-related topics.`,
  })

  return result.toDataStreamResponse()
}
