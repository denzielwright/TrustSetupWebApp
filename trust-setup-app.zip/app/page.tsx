"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, FileText, Users, DollarSign, Shield, AlertCircle } from "lucide-react"
import TrustBasicsForm from "@/components/trust-basics-form"
import AssetManagement from "@/components/asset-management"
import BeneficiarySetup from "@/components/beneficiary-setup"
import DocumentGeneration from "@/components/document-generation"
import NotarizationCheckpoint from "@/components/notarization-checkpoint"

const steps = [
  { id: 1, title: "Trust Basics", icon: Shield, description: "Basic trust information" },
  { id: 2, title: "Assets", icon: DollarSign, description: "Add trust assets" },
  { id: 3, title: "Beneficiaries", icon: Users, description: "Set beneficiaries" },
  { id: 4, title: "Documents", icon: FileText, description: "Generate documents" },
  { id: 5, title: "Notarization", icon: CheckCircle, description: "Finalize trust" },
]

export default function TrustSetupApp() {
  const [currentStep, setCurrentStep] = useState(0)
  const [isStarted, setIsStarted] = useState(false)
  const [trustData, setTrustData] = useState({
    basics: {},
    assets: [],
    beneficiaries: [],
    documents: [],
  })

  const progress = ((currentStep + 1) / steps.length) * 100

  const handleNext = (data: any) => {
    const stepKey = ["basics", "assets", "beneficiaries", "documents", "notarization"][currentStep]
    setTrustData((prev) => ({ ...prev, [stepKey]: data }))

    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    }
  }

  if (!isStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-3xl font-bold text-gray-900">Living Revocable Trust Setup</CardTitle>
            <CardDescription className="text-lg text-gray-600 mt-2">
              Create your personalized living trust with AI-powered guidance. Streamlined, secure, and legally
              compliant.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <h3 className="font-semibold">AI-Generated Documents</h3>
                <p className="text-sm text-gray-600">Legally compliant trust documents</p>
              </div>
              <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                <AlertCircle className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                <h3 className="font-semibold">Smart Checkpoints</h3>
                <p className="text-sm text-gray-600">Automated notarization alerts</p>
              </div>
              <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                <Shield className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <h3 className="font-semibold">Secure & Private</h3>
                <p className="text-sm text-gray-600">Your data stays protected</p>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">What You'll Need:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Personal identification information</li>
                <li>• List of assets to include in the trust</li>
                <li>• Beneficiary information</li>
                <li>• About 15-20 minutes to complete</li>
              </ul>
            </div>

            <Button onClick={() => setIsStarted(true)} className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6">
              Start Trust Setup
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Shield className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">Trust Setup</h1>
            </div>
            <div className="text-sm text-gray-600">
              Step {currentStep + 1} of {steps.length}
            </div>
          </div>
          <div className="mt-4">
            <Progress value={progress} className="h-2" />
          </div>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex justify-between mb-8">
          {steps.map((step, index) => {
            const Icon = step.icon
            const isActive = index === currentStep
            const isCompleted = index < currentStep

            return (
              <div key={step.id} className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                    isCompleted
                      ? "bg-green-600 text-white"
                      : isActive
                        ? "bg-blue-600 text-white"
                        : "bg-gray-200 text-gray-400"
                  }`}
                >
                  {isCompleted ? <CheckCircle className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                </div>
                <div className="text-center">
                  <div
                    className={`text-sm font-medium ${
                      isActive ? "text-blue-600" : isCompleted ? "text-green-600" : "text-gray-400"
                    }`}
                  >
                    {step.title}
                  </div>
                  <div className="text-xs text-gray-500 hidden sm:block">{step.description}</div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Step Content */}
        <div className="bg-white rounded-lg shadow-sm">
          {currentStep === 0 && <TrustBasicsForm data={trustData.basics} onNext={handleNext} onBack={handleBack} />}
          {currentStep === 1 && <AssetManagement data={trustData.assets} onNext={handleNext} onBack={handleBack} />}
          {currentStep === 2 && (
            <BeneficiarySetup data={trustData.beneficiaries} onNext={handleNext} onBack={handleBack} />
          )}
          {currentStep === 3 && <DocumentGeneration trustData={trustData} onNext={handleNext} onBack={handleBack} />}
          {currentStep === 4 && <NotarizationCheckpoint trustData={trustData} onBack={handleBack} />}
        </div>
      </div>
    </div>
  )
}
