"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Users, Plus, Trash2, Bot, User, Heart } from "lucide-react"

interface Beneficiary {
  id: string
  name: string
  relationship: string
  percentage: string
  address: string
  phone: string
}

interface BeneficiarySetupProps {
  data: Beneficiary[]
  onNext: (data: Beneficiary[]) => void
  onBack: () => void
}

const relationships = [
  "Spouse",
  "Child",
  "Parent",
  "Sibling",
  "Grandchild",
  "Other Family",
  "Friend",
  "Charity",
  "Other",
]

export default function BeneficiarySetup({ data, onNext, onBack }: BeneficiarySetupProps) {
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>(data.length > 0 ? data : [])
  const [newBeneficiary, setNewBeneficiary] = useState({
    name: "",
    relationship: "",
    percentage: "",
    address: "",
    phone: "",
  })

  const addBeneficiary = () => {
    if (newBeneficiary.name && newBeneficiary.relationship) {
      const beneficiary: Beneficiary = {
        id: Date.now().toString(),
        ...newBeneficiary,
      }
      setBeneficiaries((prev) => [...prev, beneficiary])
      setNewBeneficiary({ name: "", relationship: "", percentage: "", address: "", phone: "" })
    }
  }

  const removeBeneficiary = (id: string) => {
    setBeneficiaries((prev) => prev.filter((b) => b.id !== id))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onNext(beneficiaries)
  }

  const totalPercentage = beneficiaries.reduce((sum, b) => sum + (Number.parseFloat(b.percentage) || 0), 0)

  return (
    <form onSubmit={handleSubmit}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Users className="w-5 h-5" />
          <span>Beneficiaries</span>
        </CardTitle>
        <CardDescription>
          Specify who will receive your trust assets. You can add multiple beneficiaries and specify percentages.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Add New Beneficiary */}
        <Card className="border-dashed border-2 border-gray-300">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Plus className="w-5 h-5" />
              <span>Add Beneficiary</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input
                  value={newBeneficiary.name}
                  onChange={(e) => setNewBeneficiary((prev) => ({ ...prev, name: e.target.value }))}
                  placeholder="Jane Doe"
                />
              </div>

              <div className="space-y-2">
                <Label>Relationship</Label>
                <Select
                  value={newBeneficiary.relationship}
                  onValueChange={(value) => setNewBeneficiary((prev) => ({ ...prev, relationship: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                  <SelectContent>
                    {relationships.map((rel) => (
                      <SelectItem key={rel} value={rel}>
                        {rel}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Percentage (%)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={newBeneficiary.percentage}
                  onChange={(e) => setNewBeneficiary((prev) => ({ ...prev, percentage: e.target.value }))}
                  placeholder="50"
                />
              </div>

              <div className="space-y-2">
                <Label>Phone Number</Label>
                <Input
                  type="tel"
                  value={newBeneficiary.phone}
                  onChange={(e) => setNewBeneficiary((prev) => ({ ...prev, phone: e.target.value }))}
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Address</Label>
              <Input
                value={newBeneficiary.address}
                onChange={(e) => setNewBeneficiary((prev) => ({ ...prev, address: e.target.value }))}
                placeholder="123 Main Street, City, State, ZIP"
              />
            </div>

            <Button
              type="button"
              onClick={addBeneficiary}
              disabled={!newBeneficiary.name || !newBeneficiary.relationship}
            >
              Add Beneficiary
            </Button>
          </CardContent>
        </Card>

        {/* Beneficiary List */}
        {beneficiaries.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Beneficiaries ({beneficiaries.length})</h3>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Total:</span>
                <Badge
                  variant={totalPercentage === 100 ? "default" : totalPercentage > 100 ? "destructive" : "secondary"}
                >
                  {totalPercentage}%
                </Badge>
              </div>
            </div>

            {beneficiaries.map((beneficiary) => (
              <Card key={beneficiary.id}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <User className="w-4 h-4" />
                        <Badge variant="secondary">{beneficiary.relationship}</Badge>
                        {beneficiary.percentage && <Badge variant="outline">{beneficiary.percentage}%</Badge>}
                      </div>
                      <h4 className="font-medium">{beneficiary.name}</h4>
                      {beneficiary.address && <p className="text-sm text-gray-600 mt-1">{beneficiary.address}</p>}
                      {beneficiary.phone && <p className="text-sm text-gray-600">{beneficiary.phone}</p>}
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeBeneficiary(beneficiary.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {totalPercentage !== 100 && (
              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <div className="flex items-start space-x-2">
                  <Bot className="w-5 h-5 text-amber-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-800">Percentage Notice</h4>
                    <p className="text-sm text-amber-700 mt-1">
                      {totalPercentage < 100
                        ? `Your percentages total ${totalPercentage}%. The remaining ${100 - totalPercentage}% will be distributed equally among beneficiaries.`
                        : `Your percentages total ${totalPercentage}%, which exceeds 100%. Please adjust the percentages.`}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {beneficiaries.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Heart className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No beneficiaries added yet. Add your first beneficiary above.</p>
          </div>
        )}

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-2">
            <Bot className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-800">AI Guidance</h4>
              <p className="text-sm text-blue-700 mt-1">
                Consider naming contingent beneficiaries in case your primary beneficiaries predecease you. You can also
                specify different distribution methods (per stirpes vs. per capita) for children and grandchildren.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-6">
          <Button type="button" variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button type="submit" disabled={beneficiaries.length === 0}>
            Continue to Documents
          </Button>
        </div>
      </CardContent>
    </form>
  )
}
