"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { CheckCircle, AlertTriangle, FileText, MapPin, Calendar, Bot } from "lucide-react"

interface NotarizationCheckpointProps {
  trustData: any
  onBack: () => void
}

const notarizationSteps = [
  {
    id: "review-documents",
    title: "Review All Documents",
    description: "Carefully read through all generated trust documents",
    completed: false,
  },
  {
    id: "find-notary",
    title: "Find a Notary Public",
    description: "Locate a licensed notary in your area or schedule mobile notary service",
    completed: false,
  },
  {
    id: "bring-id",
    title: "Bring Valid ID",
    description: "Bring government-issued photo identification to the notarization",
    completed: false,
  },
  {
    id: "sign-documents",
    title: "Sign Documents",
    description: "Sign the trust agreement and pour-over will in the presence of the notary",
    completed: false,
  },
]

export default function NotarizationCheckpoint({ trustData, onBack }: NotarizationCheckpointProps) {
  const [checkedSteps, setCheckedSteps] = useState<string[]>([])
  const [isCompleted, setIsCompleted] = useState(false)

  const handleStepCheck = (stepId: string, checked: boolean) => {
    if (checked) {
      setCheckedSteps((prev) => [...prev, stepId])
    } else {
      setCheckedSteps((prev) => prev.filter((id) => id !== stepId))
    }
  }

  const handleComplete = () => {
    setIsCompleted(true)
  }

  const allStepsChecked = checkedSteps.length === notarizationSteps.length

  if (isCompleted) {
    return (
      <div>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-green-600">
            <CheckCircle className="w-6 h-6" />
            <span>Trust Setup Complete!</span>
          </CardTitle>
          <CardDescription>Congratulations! Your living revocable trust has been successfully created.</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="bg-green-50 p-6 rounded-lg border border-green-200">
            <h3 className="text-lg font-semibold text-green-800 mb-4">What's Next?</h3>
            <div className="space-y-3 text-sm text-green-700">
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 mt-0.5" />
                <span>Fund your trust by transferring assets according to the funding instructions</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 mt-0.5" />
                <span>Store your original documents in a safe place</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 mt-0.5" />
                <span>Inform your beneficiaries about the trust</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 mt-0.5" />
                <span>Review and update your trust periodically</span>
              </div>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Trust Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Trust Name:</span>
                  <p>{trustData.basics?.trustName}</p>
                </div>
                <div>
                  <span className="font-medium">Grantor/Trustee:</span>
                  <p>{trustData.basics?.grantorName}</p>
                </div>
                <div>
                  <span className="font-medium">Assets Included:</span>
                  <p>{trustData.assets?.length || 0} items</p>
                </div>
                <div>
                  <span className="font-medium">Beneficiaries:</span>
                  <p>{trustData.beneficiaries?.length || 0} people</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button className="bg-green-600 hover:bg-green-700">
              <FileText className="w-4 h-4 mr-2" />
              Download Complete Trust Package
            </Button>
          </div>
        </CardContent>
      </div>
    )
  }

  return (
    <div>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          <span>Notarization Required</span>
        </CardTitle>
        <CardDescription>
          To make your trust legally effective, certain documents must be notarized. Follow these steps to complete the
          process.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-amber-800">Important Notice</h4>
              <p className="text-sm text-amber-700 mt-1">
                The following documents require notarization: Living Trust Agreement and Pour-Over Will. Without proper
                notarization, these documents may not be legally enforceable.
              </p>
            </div>
          </div>
        </div>

        {/* Notarization Steps */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Notarization Checklist</h3>
          {notarizationSteps.map((step) => (
            <Card key={step.id} className={checkedSteps.includes(step.id) ? "border-green-200 bg-green-50" : ""}>
              <CardContent className="pt-6">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id={step.id}
                    checked={checkedSteps.includes(step.id)}
                    onCheckedChange={(checked) => handleStepCheck(step.id, checked as boolean)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <label htmlFor={step.id} className="font-medium cursor-pointer">
                      {step.title}
                    </label>
                    <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                  </div>
                  {checkedSteps.includes(step.id) && <CheckCircle className="w-5 h-5 text-green-600" />}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Notary Finder */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <MapPin className="w-5 h-5" />
              <span>Find a Notary</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Local Notary Services</h4>
                <p className="text-sm text-gray-600 mb-3">Visit banks, UPS stores, or legal offices in your area</p>
                <Button variant="outline" size="sm">
                  <MapPin className="w-4 h-4 mr-2" />
                  Find Nearby
                </Button>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Mobile Notary</h4>
                <p className="text-sm text-gray-600 mb-3">Schedule a notary to come to your location</p>
                <Button variant="outline" size="sm">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule Visit
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-2">
            <Bot className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-800">AI Reminder</h4>
              <p className="text-sm text-blue-700 mt-1">
                Don't sign the documents before meeting with the notary. The notary must witness your signature for the
                notarization to be valid. Bring a valid government-issued photo ID.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-6">
          <Button type="button" variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button onClick={handleComplete} disabled={!allStepsChecked} className="bg-green-600 hover:bg-green-700">
            Complete Trust Setup
          </Button>
        </div>
      </CardContent>
    </div>
  )
}
