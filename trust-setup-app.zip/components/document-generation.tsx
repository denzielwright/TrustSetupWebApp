"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Download, Bot, CheckCircle, Clock, AlertTriangle } from "lucide-react"

interface DocumentGenerationProps {
  trustData: any
  onNext: (data: any) => void
  onBack: () => void
}

const documents = [
  {
    id: "trust-agreement",
    name: "Living Trust Agreement",
    description: "The main trust document establishing your revocable living trust",
    status: "ready",
    requiresNotarization: true,
  },
  {
    id: "pour-over-will",
    name: "Pour-Over Will",
    description: "Ensures any assets not in the trust are transferred to it upon death",
    status: "ready",
    requiresNotarization: true,
  },
  {
    id: "assignment-personal-property",
    name: "Assignment of Personal Property",
    description: "Transfers personal property into the trust",
    status: "ready",
    requiresNotarization: false,
  },
  {
    id: "funding-instructions",
    name: "Trust Funding Instructions",
    description: "Step-by-step guide for transferring assets into your trust",
    status: "ready",
    requiresNotarization: false,
  },
]

export default function DocumentGeneration({ trustData, onNext, onBack }: DocumentGenerationProps) {
  const [generatingDocs, setGeneratingDocs] = useState(false)
  const [generatedDocs, setGeneratedDocs] = useState<string[]>([])

  const generateDocuments = async () => {
    setGeneratingDocs(true)

    // Simulate AI document generation
    for (let i = 0; i < documents.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setGeneratedDocs((prev) => [...prev, documents[i].id])
    }

    setGeneratingDocs(false)
  }

  const handleSubmit = () => {
    onNext({ documents: generatedDocs, trustData })
  }

  const getStatusIcon = (docId: string) => {
    if (generatingDocs && !generatedDocs.includes(docId)) {
      return <Clock className="w-4 h-4 text-amber-600" />
    }
    if (generatedDocs.includes(docId)) {
      return <CheckCircle className="w-4 h-4 text-green-600" />
    }
    return <FileText className="w-4 h-4 text-gray-400" />
  }

  const getStatusText = (docId: string) => {
    if (generatingDocs && !generatedDocs.includes(docId)) {
      return "Generating..."
    }
    if (generatedDocs.includes(docId)) {
      return "Ready"
    }
    return "Pending"
  }

  const allDocsGenerated = generatedDocs.length === documents.length

  return (
    <div>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="w-5 h-5" />
          <span>Document Generation</span>
        </CardTitle>
        <CardDescription>
          AI will generate your personalized trust documents based on the information you've provided.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Trust Summary */}
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Bot className="w-5 h-5 text-blue-600" />
              <span>Trust Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Trust Name:</span> {trustData.basics?.trustName || "Not specified"}
              </div>
              <div>
                <span className="font-medium">Grantor/Trustee:</span> {trustData.basics?.grantorName || "Not specified"}
              </div>
              <div>
                <span className="font-medium">Assets:</span> {trustData.assets?.length || 0} items
              </div>
              <div>
                <span className="font-medium">Beneficiaries:</span> {trustData.beneficiaries?.length || 0} people
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Document List */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Trust Documents</h3>
          {documents.map((doc) => (
            <Card key={doc.id} className={generatedDocs.includes(doc.id) ? "border-green-200 bg-green-50" : ""}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      {getStatusIcon(doc.id)}
                      <h4 className="font-medium">{doc.name}</h4>
                      <Badge variant={getStatusText(doc.id) === "Ready" ? "default" : "secondary"}>
                        {getStatusText(doc.id)}
                      </Badge>
                      {doc.requiresNotarization && (
                        <Badge variant="outline" className="text-amber-600 border-amber-600">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          Notarization Required
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{doc.description}</p>
                  </div>
                  {generatedDocs.includes(doc.id) && (
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {!allDocsGenerated && (
          <div className="bg-gray-50 p-6 rounded-lg text-center">
            <Bot className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold mb-2">Ready to Generate Documents</h3>
            <p className="text-gray-600 mb-4">
              Our AI will create personalized legal documents based on your trust information. This process typically
              takes 2-3 minutes.
            </p>
            <Button onClick={generateDocuments} disabled={generatingDocs} className="bg-blue-600 hover:bg-blue-700">
              {generatingDocs ? (
                <>
                  <Clock className="w-4 h-4 mr-2 animate-spin" />
                  Generating Documents...
                </>
              ) : (
                <>
                  <Bot className="w-4 h-4 mr-2" />
                  Generate Trust Documents
                </>
              )}
            </Button>
          </div>
        )}

        {allDocsGenerated && (
          <div className="bg-green-50 p-6 rounded-lg border border-green-200">
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-6 h-6 text-green-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-green-800 mb-2">Documents Generated Successfully!</h4>
                <p className="text-sm text-green-700 mb-4">
                  Your trust documents have been generated and are ready for review. Some documents require notarization
                  to be legally effective.
                </p>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download All Documents
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-between pt-6">
          <Button type="button" variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button onClick={handleSubmit} disabled={!allDocsGenerated}>
            Continue to Notarization
          </Button>
        </div>
      </CardContent>
    </div>
  )
}
