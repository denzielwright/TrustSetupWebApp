"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { DollarSign, Plus, Trash2, Bot, Home, Car, Banknote, Building } from "lucide-react"

interface Asset {
  id: string
  type: string
  description: string
  value: string
  details: string
}

interface AssetManagementProps {
  data: Asset[]
  onNext: (data: Asset[]) => void
  onBack: () => void
}

const assetTypes = [
  { value: "real-estate", label: "Real Estate", icon: Home },
  { value: "bank-account", label: "Bank Account", icon: Banknote },
  { value: "investment", label: "Investment Account", icon: Building },
  { value: "vehicle", label: "Vehicle", icon: Car },
  { value: "personal-property", label: "Personal Property", icon: DollarSign },
  { value: "other", label: "Other", icon: DollarSign },
]

export default function AssetManagement({ data, onNext, onBack }: AssetManagementProps) {
  const [assets, setAssets] = useState<Asset[]>(data.length > 0 ? data : [])
  const [newAsset, setNewAsset] = useState({
    type: "",
    description: "",
    value: "",
    details: "",
  })

  const addAsset = () => {
    if (newAsset.type && newAsset.description) {
      const asset: Asset = {
        id: Date.now().toString(),
        ...newAsset,
      }
      setAssets((prev) => [...prev, asset])
      setNewAsset({ type: "", description: "", value: "", details: "" })
    }
  }

  const removeAsset = (id: string) => {
    setAssets((prev) => prev.filter((asset) => asset.id !== id))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onNext(assets)
  }

  const getAssetIcon = (type: string) => {
    const assetType = assetTypes.find((t) => t.value === type)
    const Icon = assetType?.icon || DollarSign
    return <Icon className="w-4 h-4" />
  }

  const getAssetLabel = (type: string) => {
    return assetTypes.find((t) => t.value === type)?.label || type
  }

  return (
    <form onSubmit={handleSubmit}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <DollarSign className="w-5 h-5" />
          <span>Trust Assets</span>
        </CardTitle>
        <CardDescription>
          Add the assets you want to include in your trust. You can always modify this list later.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Add New Asset */}
        <Card className="border-dashed border-2 border-gray-300">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Plus className="w-5 h-5" />
              <span>Add Asset</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Asset Type</Label>
                <Select
                  value={newAsset.type}
                  onValueChange={(value) => setNewAsset((prev) => ({ ...prev, type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select asset type" />
                  </SelectTrigger>
                  <SelectContent>
                    {assetTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center space-x-2">
                          <type.icon className="w-4 h-4" />
                          <span>{type.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Estimated Value</Label>
                <Input
                  type="text"
                  value={newAsset.value}
                  onChange={(e) => setNewAsset((prev) => ({ ...prev, value: e.target.value }))}
                  placeholder="$100,000"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={newAsset.description}
                onChange={(e) => setNewAsset((prev) => ({ ...prev, description: e.target.value }))}
                placeholder="e.g., Primary residence at 123 Main St"
              />
            </div>

            <div className="space-y-2">
              <Label>Additional Details (Optional)</Label>
              <Textarea
                value={newAsset.details}
                onChange={(e) => setNewAsset((prev) => ({ ...prev, details: e.target.value }))}
                placeholder="Account numbers, legal descriptions, or other relevant details"
              />
            </div>

            <Button type="button" onClick={addAsset} disabled={!newAsset.type || !newAsset.description}>
              Add Asset
            </Button>
          </CardContent>
        </Card>

        {/* Asset List */}
        {assets.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Trust Assets ({assets.length})</h3>
            {assets.map((asset) => (
              <Card key={asset.id}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        {getAssetIcon(asset.type)}
                        <Badge variant="secondary">{getAssetLabel(asset.type)}</Badge>
                        {asset.value && <Badge variant="outline">{asset.value}</Badge>}
                      </div>
                      <h4 className="font-medium">{asset.description}</h4>
                      {asset.details && <p className="text-sm text-gray-600 mt-1">{asset.details}</p>}
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeAsset(asset.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {assets.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <DollarSign className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No assets added yet. Add your first asset above.</p>
          </div>
        )}

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-2">
            <Bot className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-800">AI Recommendation</h4>
              <p className="text-sm text-blue-700 mt-1">
                Consider including your primary residence, bank accounts, and investment accounts. Personal property
                like jewelry or artwork can be added as a single "Personal Property" entry or itemized based on value
                and importance.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-6">
          <Button type="button" variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button type="submit">Continue to Beneficiaries</Button>
        </div>
      </CardContent>
    </form>
  )
}
