"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Bot, User } from "lucide-react"

interface TrustBasicsFormProps {
  data: any
  onNext: (data: any) => void
  onBack: () => void
}

export default function TrustBasicsForm({ data, onNext, onBack }: TrustBasicsFormProps) {
  const [formData, setFormData] = useState({
    trustName: data.trustName || "",
    grantorName: data.grantorName || "",
    grantorAddress: data.grantorAddress || "",
    grantorPhone: data.grantorPhone || "",
    grantorEmail: data.grantorEmail || "",
    state: data.state || "",
    trustPurpose: data.trustPurpose || "",
    ...data,
  })

  const [aiSuggestion, setAiSuggestion] = useState("")

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))

    // Simulate AI suggestion for trust name
    if (field === "grantorName" && value.length > 2) {
      setAiSuggestion(`${value} Living Trust`)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onNext(formData)
  }

  const isValid = formData.trustName && formData.grantorName && formData.grantorAddress && formData.state

  return (
    <form onSubmit={handleSubmit}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <User className="w-5 h-5" />
          <span>Trust Basics</span>
        </CardTitle>
        <CardDescription>
          Let's start with the fundamental information for your living revocable trust. You'll serve as both the grantor
          (creator) and trustee (manager) of this trust.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="grantorName">Your Full Legal Name</Label>
            <Input
              id="grantorName"
              value={formData.grantorName}
              onChange={(e) => handleInputChange("grantorName", e.target.value)}
              placeholder="John Doe"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="trustName">Trust Name</Label>
            <div className="relative">
              <Input
                id="trustName"
                value={formData.trustName}
                onChange={(e) => handleInputChange("trustName", e.target.value)}
                placeholder="Enter trust name"
                required
              />
              {aiSuggestion && (
                <div className="mt-2 p-2 bg-blue-50 rounded-md border border-blue-200">
                  <div className="flex items-center space-x-2 text-sm">
                    <Bot className="w-4 h-4 text-blue-600" />
                    <span className="text-blue-800">AI Suggestion:</span>
                    <button
                      type="button"
                      onClick={() => handleInputChange("trustName", aiSuggestion)}
                      className="text-blue-600 hover:text-blue-800 underline"
                    >
                      {aiSuggestion}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="grantorAddress">Your Address</Label>
          <Textarea
            id="grantorAddress"
            value={formData.grantorAddress}
            onChange={(e) => handleInputChange("grantorAddress", e.target.value)}
            placeholder="123 Main Street, City, State, ZIP"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="grantorPhone">Phone Number</Label>
            <Input
              id="grantorPhone"
              type="tel"
              value={formData.grantorPhone}
              onChange={(e) => handleInputChange("grantorPhone", e.target.value)}
              placeholder="(555) 123-4567"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="grantorEmail">Email Address</Label>
            <Input
              id="grantorEmail"
              type="email"
              value={formData.grantorEmail}
              onChange={(e) => handleInputChange("grantorEmail", e.target.value)}
              placeholder="john@example.com"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="state">State</Label>
          <Select value={formData.state} onValueChange={(value) => handleInputChange("state", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select your state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="CA">California</SelectItem>
              <SelectItem value="NY">New York</SelectItem>
              <SelectItem value="TX">Texas</SelectItem>
              <SelectItem value="FL">Florida</SelectItem>
              <SelectItem value="IL">Illinois</SelectItem>
              {/* Add more states as needed */}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="trustPurpose">Trust Purpose (Optional)</Label>
          <Textarea
            id="trustPurpose"
            value={formData.trustPurpose}
            onChange={(e) => handleInputChange("trustPurpose", e.target.value)}
            placeholder="Describe the main purpose of your trust (e.g., estate planning, asset protection, avoiding probate)"
          />
        </div>

        <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
          <div className="flex items-start space-x-2">
            <Bot className="w-5 h-5 text-amber-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-amber-800">AI Insight</h4>
              <p className="text-sm text-amber-700 mt-1">
                As both grantor and trustee, you'll maintain full control over your trust assets during your lifetime.
                This setup provides flexibility while ensuring your assets avoid probate upon your passing.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-6">
          <Button type="button" variant="outline" onClick={onBack}>
            Back
          </Button>
          <Button type="submit" disabled={!isValid}>
            Continue to Assets
          </Button>
        </div>
      </CardContent>
    </form>
  )
}
